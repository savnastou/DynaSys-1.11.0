
package sifive.fpgashells.ip.xilinx
import chisel3._
import chisel3.experimental.{Analog, DoubleParam, IntParam, RawParam, StringParam, attach}
import sifive.blocks.devices.pinctrl.BasePin

object booleanToVerilogVectorParam extends (Boolean => RawParam) {
  def apply(b : Boolean) : RawParam =  if(b) RawParam("1") else RawParam("0")
}

object booleanToVerilogStringParam extends (Boolean => StringParam) {
  def apply(b : Boolean) : StringParam = if(b) StringParam("""TRUE""") else StringParam("""FALSE""")
}


/** IBUFDS -- SelectIO Differential Input */

class IBUFDS(
  CAPACITANCE : String = "DONT_CARE",
  DIFF_TERM : Boolean = false,
  DQS_BIAS : Boolean = false,
  IBUF_DELAY_VALUE : Int = 0,
  IBUF_LOW_PWR : Boolean = true,
  IFD_DELAY_VALUE : String = "AUTO",
  IOSTANDARD : String = "DEFAULT"
)
extends BlackBox(
  Map(
  "CAPACITANCE" -> StringParam(CAPACITANCE),
  "DIFF_TERM" -> booleanToVerilogStringParam(DIFF_TERM),
  "DQS_BIAS" -> booleanToVerilogStringParam(DQS_BIAS),
  "IBUF_DELAY_VALUE" -> IntParam(IBUF_DELAY_VALUE),
  "IBUF_LOW_PWR" -> booleanToVerilogStringParam(IBUF_LOW_PWR),
  "IFD_DELAY_VALUE" -> StringParam(IFD_DELAY_VALUE),
  "IOSTANDARD" -> StringParam(IOSTANDARD)
  )
) {
  val io = IO(new Bundle {
    val O  = Output(Clock())
    val I  = Input(Clock())
    val IB = Input(Clock())
  })
}

/** IBUFG -- Clock Input Buffer */

class IBUFG extends BlackBox {
  val io = IO(new Bundle {
    val O = Output(Clock())
    val I = Input(Clock())
  })
}

object IBUFG {
  def apply (pin: Clock): Clock = {
    val pad = Module (new IBUFG())
    pad.io.I := pin
    pad.io.O
  }
}

/** IBUF -- Input Buffer */

class IBUF extends BlackBox {
  val io = IO(new Bundle {
    val O = Output(Bool())
    val I = Input(Bool())
  })
}

object IBUF {
  def apply(pin: Bool): Bool = {
    val pad = Module (new IBUF)
    pad.io.I := pin
    pad.io.O
  }
}

/** IBUFDS_GTE2 -- Differential Signaling Input Buffer */

class IBUFDS_GTE2(
  CLKCM_CFG : Boolean = true,
  CLKRCV_TRST : Boolean = true,
  CLKSWING_CFG : Int = 3
)
extends BlackBox(
  Map(
  "CLKCM_CFG" -> booleanToVerilogStringParam(CLKCM_CFG),
  "CLKRCV_TRST" -> booleanToVerilogStringParam(CLKCM_CFG),
  "CLKSWING_CFG" -> IntParam(CLKSWING_CFG)
  )
) {
  val io = IO(new Bundle {
    val O         = Output(Bool())
    val ODIV2     = Output(Bool())
    val CEB       = Input(Bool())
    val I         = Input(Bool())
    val IB        = Input(Bool())
  })
}

class IBUFDS_GTE4(
    REFCLK_EN_TX_PATH:  Int = 0,
    REFCLK_HROW_CK_SEL: Int = 0,
    REFCLK_ICNTL_RX:    Int = 0)
  extends BlackBox(Map(
    "REFCLK_EN_TX_PATH"  -> IntParam(REFCLK_EN_TX_PATH),
    "REFCLK_HROW_CK_SEL" -> IntParam(REFCLK_HROW_CK_SEL),
    "REFCLK_ICNTL_RX"    -> IntParam(REFCLK_ICNTL_RX)))
{
  val io = IO(new Bundle {
    val O     = Output(Clock())
    val ODIV2 = Output(Clock())
    val CEB   = Input(Bool())
    val I     = Input(Clock())
    val IB    = Input(Clock())
  })

}
/** STARTUPE3 -- Primitive block to enable application communication with flash device on vcu118. */

class STARTUPE3(
  PROG_USR : Boolean = false,
  SIM_CCLK_FREQ : Double = 0
) 
extends BlackBox(
  Map(
    "PROG_USR" -> booleanToVerilogStringParam(PROG_USR),
    "SIM_CCLK_FREQ" ->  DoubleParam(SIM_CCLK_FREQ)
  )
) {
  val io = IO(new Bundle {
    val CFGCLK = Output(Clock())
    val CFGMCLK = Output(Clock())
    val DI = Output(UInt(4.W))
    val EOS = Output(Bool())
    val PREQ = Output(Bool())
    val DO = Input(UInt(4.W))
    val DTS = Input(UInt(4.W))
    val FCSBO = Input(Bool())
    val FCSBTS = Input(Bool())
    val GSR = Input(Bool())
    val GTS = Input(Bool())
    val KEYCLEARB = Input(Bool())
    val PACK = Input(Bool())
    val USRCCLKO = Input(Clock())
    val USRCCLKTS = Input(Bool())
    val USRDONEO = Input(Bool())
    val USRDONETS = Input(Bool())
  })
}

/** IDDR - 7 Series SelectIO DDR flop */

class IDDR(
  DDR_CLK_EDGE : String = "OPPOSITE_EDGE",
  INIT_Q1 : Boolean = false,
  INIT_Q2 : Boolean = false,
  IS_C_INVERTED : Boolean = false,
  IS_D_INVERTED : Boolean = false,
  SRTYPE : String = "SYNC"
)
extends BlackBox(
  Map(
    "DDR_CLK_EDGE" -> StringParam(DDR_CLK_EDGE),
    "INIT_Q1" -> booleanToVerilogVectorParam(INIT_Q1),
    "INIT_Q2" -> booleanToVerilogVectorParam(INIT_Q2),
    "IS_C_INVERTED" -> booleanToVerilogVectorParam(IS_C_INVERTED),
    "IS_D_INVERTED" -> booleanToVerilogVectorParam(IS_D_INVERTED),
    "SRTYPE" -> StringParam(SRTYPE)
  ) 
) {
  val io = IO(new Bundle {
    val Q1 = Output(Bool())
    val Q2 = Output(Bool())
    val C = Input(Bool())
    val CE = Input(Bool())
    val D = Input(Bool())
    val R = Input(Bool())
    val S = Input(Bool())
  })
} 

/** IDELAYCTRL - 7 Series SelectIO */

class IDELAYCTRL(
  sim_device : String = "7SERIES"
) 
extends BlackBox(
  Map(
    "SIM_DEVICE" -> StringParam(sim_device)
  )
) {
  val io = IO(new Bundle {
    val RDY = Output(Bool())
    val REFCLK = Input(Bool())
    val RST = Input(Bool())
  })
}


/** IDELAYE2 -- 7 Series SelectIO ILogic programmable delay. */

class IDELAYE2(
  CINVCTRL_SEL : Boolean = false,
  DELAY_SRC : String = "IDATAIN",
  HIGH_PERFORMANCE_MODE : Boolean = false,
  IDELAY_TYPE : String = "FIXED",
  IDELAY_VALUE : Int = 0,
  IS_C_INVERTED : Boolean = false,
  IS_DATAIN_INVERTED : Boolean = false,
  IS_IDATAIN_INVERTED : Boolean = false,
  PIPE_SEL : Boolean = false,
  REFCLK_FREQUENCY : Double = 200.0,
  SIGNAL_PATTERN : String  = "DATA",
  SIM_DELAY_D : Int = 0
) 
extends BlackBox(
  Map(
    "CINVCTRL_SEL" -> booleanToVerilogStringParam(CINVCTRL_SEL),
    "DELAY_SRC" -> StringParam(DELAY_SRC),
    "HIGH_PERFORMANCE_MODE" -> booleanToVerilogStringParam(HIGH_PERFORMANCE_MODE),
    "IDELAY_TYPE" -> StringParam(IDELAY_TYPE),
    "IS_C_INVERTED" -> booleanToVerilogVectorParam(IS_C_INVERTED),
    "IS_DATAIN_INVERTED" -> booleanToVerilogVectorParam(IS_DATAIN_INVERTED),
    "IS_IDATAIN_INVERTED" -> booleanToVerilogVectorParam(IS_IDATAIN_INVERTED),
    "PIPE_SEL" -> booleanToVerilogStringParam(PIPE_SEL),
    "REFCLK_FREQUENCY" ->  DoubleParam(REFCLK_FREQUENCY),
    "SIGNAL_PATTERN" -> StringParam(SIGNAL_PATTERN),
    "SIM_DELAY_D" -> IntParam(SIM_DELAY_D)
  )
) {
  val io = IO(new Bundle {
    val DATAOUT = Output(Bool())
    val CNTVALUEOUT = Output(UInt(5.W))
    val C = Input(Bool())
    val CE = Input(Bool())
    val CINVCTRL = Input(Bool())
    val DATAIN = Input(Bool())
    val IDATAIN = Input(Bool())
    val INC = Input(Bool())
    val LD = Input(Bool())
    val LDPIPEEN = Input(Bool())
    val REGRST = Input(Bool())
    val CNTVALUEIN = Input(UInt(5.W))
  })
}

/** IOBUF -- Bidirectional IO Buffer. */

//Cannot convert to BlackBox because of line 
//val IO = IO(Analog(1.W)) 
//is illegal

class IOBUF extends BlackBox {

  val io = IO(new Bundle {
    val O = Output(Bool())
    val IO = Analog(1.W)
    val I = Input(Bool())
    val T = Input(Bool())
  })
}

object IOBUF {

    def apply (pin: Analog, ctrl: BasePin): Bool = {
      val pad = Module(new IOBUF())
      pad.io.I := ctrl.o.oval
      pad.io.T := ~ctrl.o.oe
      ctrl.i.ival := pad.io.O & ctrl.o.ie
      attach(pad.io.IO, pin)
      pad.io.O & ctrl.o.ie
  }

  // Creates an output IOBUF
  def apply (pin: Analog, in: Bool): Unit = {
    val pad = Module(new IOBUF())
    pad.io.I := in
    pad.io.T := false.B
    attach(pad.io.IO, pin)
  }

  // Creates an input IOBUF
  def apply (pin: Analog): Bool = {
    val pad = Module(new IOBUF())
    pad.io.I := false.B
    pad.io.T := true.B
    attach(pad.io.IO, pin)
    pad.io.O
  }

}

/** ODDR - 7 Series SelectIO DDR flop */

class ODDR(
  DDR_CLK_EDGE : String = "OPPOSITE_EDGE",
  INIT : Boolean = false,
  IS_C_INVERTED : Boolean = false,
  IS_D1_INVERTED : Boolean = false,
  IS_D2_INVERTED : Boolean = false,
  SRTYPE : String = "SYNC"
)
extends BlackBox(
  Map(
    "DDR_CLK_EDGE" -> StringParam(DDR_CLK_EDGE),
    "INIT" -> booleanToVerilogVectorParam(INIT),
    "IS_C_INVERTED" -> booleanToVerilogVectorParam(IS_C_INVERTED),
    "IS_D1_INVERTED" -> booleanToVerilogVectorParam(IS_D1_INVERTED),
    "IS_D2_INVERTED" -> booleanToVerilogVectorParam(IS_D2_INVERTED),
    "SRTYPE" -> StringParam(SRTYPE)
  ) 
) {
  val io = IO(new Bundle {
    val Q = Output(Bool())
    val C = Input(Clock())
    val CE = Input(Bool())
    val D1 = Input(Bool())
    val D2 = Input(Bool())
    val R = Input(Bool())
    val S = Input(Bool())
  })
} 

/** ODELAYE2 -- 7 Series SelectIO OLogic programmable delay. */

class ODELAYE2(
  CINVCTRL_SEL : Boolean = false,
  DELAY_SRC : String = "ODATAIN",
  HIGH_PERFORMANCE_MODE : Boolean = false,
  IS_C_INVERTED : Boolean = false,
  IS_ODATAIN_INVERTED : Boolean = false,
  ODELAY_TYPE : String = "FIXED",
  ODELAY_VALUE : Int = 0,
  PIPE_SEL : Boolean = false,
  REFCLK_FREQUENCY : Double = 200.0,
  SIGNAL_PATTERN : String  = "DATA",
  SIM_DELAY_D : Int = 0
) 
extends BlackBox(
  Map(
    "CINVCTRL_SEL" -> booleanToVerilogStringParam(CINVCTRL_SEL),
    "DELAY_SRC" -> StringParam(DELAY_SRC),
    "HIGH_PERFORMANCE_MODE" -> booleanToVerilogStringParam(HIGH_PERFORMANCE_MODE),
    "IS_C_INVERTED" -> booleanToVerilogVectorParam(IS_C_INVERTED),
    "IS_ODATAIN_INVERTED" -> booleanToVerilogVectorParam(IS_ODATAIN_INVERTED),
    "ODELAY_TYPE" -> StringParam(ODELAY_TYPE),
    "PIPE_SEL" -> booleanToVerilogStringParam(PIPE_SEL),
    "REFCLK_FREQUENCY" ->  DoubleParam(REFCLK_FREQUENCY),
    "SIGNAL_PATTERN" -> StringParam(SIGNAL_PATTERN),
    "SIM_DELAY_D" -> IntParam(SIM_DELAY_D)
  )
) {
  val io = IO(new Bundle { 
    val DATAOUT = Output(Bool())
    val CNTVALUEOUT = Output(UInt(5.W))
    val C = Input(Bool())
    val CE = Input(Bool())
    val CINVCTRL = Input(Bool())
    val CLKIN = Input(Bool())
    val INC = Input(Bool())
    val LD = Input(Bool())
    val LDPIPEEN = Input(Bool())
    val ODATAIN = Input(Bool())
    val REGRST = Input(Bool())
    val CNTVALUEIN = Input(UInt(5.W))
  })
}

/** PULLUP : can be applied to Input to add a Pullup. */

class PULLUP extends BlackBox {
  val io = IO(new Bundle { 
    val O = Analog(1.W)
  })
}

object PULLUP {
    def apply (pin: Analog): Unit = {
    val pullup = Module(new PULLUP())
    attach(pullup.io.O, pin)
    }
}

/** KEEPER : can be applied to I/O to hold its last value since driven. */

class KEEPER extends BlackBox {
  val io = IO(new Bundle { 
    val O = Analog(1.W)
  })
}

object KEEPER {
    def apply (pin: Analog): Unit = {
    val pullup = Module(new KEEPER())
    attach(pullup.io.O, pin)
    }
}


/*
   Copyright 2016 SiFive, Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
