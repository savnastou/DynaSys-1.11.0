package sifive.fpgashells

import chisel3._

import scala.language.implicitConversions

package object shell {
  implicit def boolToIOPin(x: Bool): IOPin = IOPin(x, 0)
  implicit def clockToIOPin(x: Clock): IOPin = IOPin(x, 0)
}

/*
   Copyright 2016 SiFive, Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
